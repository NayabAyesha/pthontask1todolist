from tkinter import *
list_root = Tk()

list_root.geometry("600x500")
list_root.title("To_Do_List")

task_list = []
def ADDTASKLIST():
    list_stringtask = list_entry.get()
    list_entry.delete(0, END)
    if list_stringtask:
        with open("list_task.txt", "a") as listfile:
            listfile.write(f"\n{list_stringtask}")
            task_list.append(list_stringtask)
            list_box.insert(END,list_stringtask)



def DELETETASK():
    global list_stringtask
    list_stringtask = list_box.get(ANCHOR)
    if list_stringtask in task_list:
        task_list.remove(list_stringtask)
        list_box.delete(ANCHOR)
        with open("list_task.txt", "w") as listfile:
            listfile.write("\n".join(task_list) + "\n")


def listtask():

     try:
         with open("list_task.txt", "r") as listfile:
             tasks = listfile.readline()

             for list_stringtask in tasks:
                 if list_stringtask != '\n':
                     list_box.insert(END, list_stringtask)

     except:
         textfile=open("list_task.txt", "r")
         textfile.close()


list_label = Label(text="\nTASK1"
                      "\nPYTHON"
                   "\nTO DO LIST", fg="orange", bg="black", width="600", height="4")
list_label.pack()

list_frame = Frame(list_root, width=700, height=50, bg="black")
list_frame.place(x=0, y=180)

list_stringtask = StringVar()
list_entry = Entry(list_frame, width=25, font="lucida 20 bold ")
list_entry.place(x=10, y=7)
list_entry.focus()

list_button = Button(list_frame, text="ADD", font="a", width=6, bg="orange", command=ADDTASKLIST)
list_button.place(x=400, y=0)
list_button = Button(list_frame, text="DELETE", font="a", width=6, bg="orange", command = DELETETASK)
list_button.place(x=500, y=0)

list_frame1 = Frame(list_root, width=700, height=280, bg="black")
list_frame1.pack(pady=(160,0))

list_box = Listbox(list_frame1,font=('arial', 12), width=600, height=16, bg="orange", fg="black", cursor = "hand2" )
list_box.pack(side=LEFT, padx =2)

list_scroolbar = Scrollbar(list_frame1)
list_scroolbar.pack(side=RIGHT)

list_box.config(yscrollcommand=Scrollbar.set)
list_scroolbar.config(command=list_box.yview)

list_root.mainloop()